<?php

$database="pdfapp";
$host="localhost";
$user="root";
$password="";

$con=mysqli_connect($host,$user,$password,$database) or die('error in connect db');




?>